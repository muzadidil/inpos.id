Folder ini hanya berisi dokumentasi migrasi fitur INPOS lama. JANGAN upload folder ini ke public_html.
Versi kasir starter belum memuat seluruh fungsi v721.
