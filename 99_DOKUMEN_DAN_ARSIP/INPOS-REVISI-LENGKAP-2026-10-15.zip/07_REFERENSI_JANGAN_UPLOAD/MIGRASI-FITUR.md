# Cakupan migrasi INPOS

## Sudah terhubung API pada starter ini
- Registrasi toko + akun Owner dengan kode undangan; login Owner/Karyawan; login Super Admin.
- Multi-Tenant melalui tabel tenant, tenantId, pembatasan peran dan cookie sesi.
- Produk, kategori string, stok satuan dasar, faktor kemasan pada data produk.
- Penjualan dan Pembelian dasar (stok atomik, requestId idempoten), tanpa pembayaran rumit.
- Web Toko: katalog, keranjang, kirim pesanan, terima/tolak pesanan oleh toko.
- Super Admin: mitra, tangguhkan/aktifkan, tarif, referensi gambar QRIS URL HTTPS, persetujuan/penolakan tagihan, masa langganan/lisensi Pajak.

## BELUM dimigrasikan dari HTML INPOS lama
- Login PIN 5–6 digit, pengingat perangkat dan impor akun dari sistem lama secara aman; reset sandi aman via verifikasi server.
- Modul kasir lengkap: diskon, PPN Include/Exclude, metode bayar, hold/shift, retur, piutang/hutang, stok opname, pembelian variabel/HPP, multiple barcode.
- Multi Satuan di UI transaksi (Box/Dus/PCS), grosir, bundling, kupon, poin, Titip Barang, produksi, varian, expiry, Sampah Produk.
- Struk PNG 58/80/A4, cetak, share, scan kamera, label dan QR meja.
- Laporan, Buku Kas, laporan keuangan, rekap pajak, Coretax, grafik, eksport CSV/PDF.
- Web Toko lanjutan (pembayaran QRIS nyata, ongkir, kurir, promo, pelanggan).
- Broadcast/push notifikasi server, sinkronisasi offline IndexedDB, event real-time WebSocket.
- Multi-level hak akses karyawan sesuai matriks dari HTML lama.
- Integrasi gateway pembayaran/webhook resmi dan audit trail persetujuan.

Prioritas migrasi: (1) keamanan tenant dan autentikasi, (2) penjualan-pembelian-stok lengkap, (3) pembayaran/piutang/HPP, (4) modul operasional, (5) laporan, (6) Toko Online dan Pajak.
