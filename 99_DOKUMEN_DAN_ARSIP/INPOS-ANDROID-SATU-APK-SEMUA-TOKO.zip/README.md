# INPOS Android — Satu APK Semua Toko

**Proyek Android Studio** yang mempertahankan tampilan web INPOS dengan membuka `https://app.inpos.id/` di Android WebView. **Bukan APK biner yang sudah dibuild.** APK debug atau release dibuat di Android Studio (SDK & Gradle harus tersedia). Satu aplikasi digunakan semua tenant; login meminta subdomain toko, username, dan PIN. Isolasi data adalah tanggung jawab backend NestJS dengan tenantId pada sesi login dan semua query tenant.

## Mengapa WebView langsung, bukan bundel lokal Capacitor?

Frontend versi saat ini memakai sesi cookie **HttpOnly + SameSite=Lax** dari `api.inpos.id` dengan CORS origin `app.inpos.id`. Jika frontend dibundel sebagai `http://localhost` dalam Capacitor, sesi cookie dianggap cross-site dan tidak otomatis bekerja tanpa perubahan besar autentikasi/CORS. WebView langsung mempertahankan origin `https://app.inpos.id`, sehingga sesi dan UI web saat ini tidak perlu dikonversi. Dibanding `server.url` Capacitor (opsi untuk live reload), ini menggunakan WebView native yang memang ditujukan untuk memuat situs produksi.

## Spesifikasi

- Nama aplikasi: INPOS
- Application ID: `id.inpos.app` (debug `id.inpos.app.debug`)
- Min SDK: 26 (Android 8.0); compile/target: API 36 (Android 16)
- Android Gradle Plugin 8.13.2, Gradle 8.13, JDK 17
- Login: `https://app.inpos.id` (semua tenant)
- API frontend: `https://api.inpos.id/v1` (sesuai file JS hosted)
- HTTPS saja, navigasi internal hanya `app.inpos.id`; tautan eksternal dibuka oleh aplikasi luar.
- Cookie sesi tetap HttpOnly di API, tidak ditransfer ke Java; cache WebView menggunakan mekanisme standar Chromium.
- Back: menutup menu Lainnya, kembali Dashboard, kemudian dialog keluar.
- Kamera: permintaan `getUserMedia` VIDEO dari origin INPOS dapat memicu izin kamera Android; tidak menambahkan kode pemindaian barcode yang belum ada di frontend.
- Pemilihan file HTML dari penyimpanan perangkat didukung melalui file chooser.
- Jika internet/server tidak tersedia, muncul halaman kesalahan dengan tombol Coba Lagi.
- Tidak menyertakan kredensial, PIN seed, token, atau kunci signing.

## Sebelum build

1. Pastikan `https://app.inpos.id` sudah online dengan sertifikat SSL valid (tanpa redirect ke domain lain), dan `https://api.inpos.id/v1/health` menampilkan respons valid.
2. Pastikan backend terbaru dan migrasi Prisma cPanel sudah diterapkan, terutama untuk database yang sudah berisi data. Backup dan uji isolasi antar-tenant sebelum dipakai produksi.
3. Opsional: upload **isi** folder `PATCH-CPANEL/02_APLIKASI_APP_INPOS_ID/` ke document root `app.inpos.id` untuk mengosongkan nilai subdomain demo saat pertama kali login dan mengingat subdomain terakhir. Simpan backup file online terlebih dahulu. Patch ini hanya menambah perilaku UI; tidak menyentuh database dan tidak mengubah API.
4. Pasang Android Studio, Android SDK Platform **API 36**, Android SDK Build-Tools yang kompatibel, **JDK 17**, serta koneksi internet untuk mengunduh Gradle/AGP ketika sinkronisasi pertama.

## Cara menghasilkan APK

**Windows:** sebelum membuka Android Studio, jalankan `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/siapkan-gradle.ps1` dari folder proyek untuk menyiapkan Gradle wrapper resmi; lalu buka folder di Android Studio -> tunggu Gradle Sync -> menu **Build > Build App Bundle(s) / APK(s) > Build APK(s)**. Alternatif: klik `BUILD-APK-WINDOWS.bat` setelah SDK/JDK dikonfigurasi.

**Linux/Mac:** dari folder proyek jalankan `./BUILD-APK-LINUX-MAC.sh` (secara otomatis mengunduh Gradle wrapper resmi). Jika akan membuka proyek langsung di Android Studio terlebih dahulu, jalankan `./scripts/siapkan-gradle.sh`.

Project membawa `gradle-wrapper.properties` dan script yang mengunduh **wrapper JAR resmi** dari Gradle dengan verifikasi SHA-256 saat pertama berjalan. Proses sync pertama membutuhkan koneksi internet. Output debug:

```
app/build/outputs/apk/debug/app-debug.apk
```

APK debug dapat dipasang manual untuk pengujian. Untuk APK distribusi bertanda tangan, gunakan Android Studio **Build > Generate Signed App Bundle / APK**, pilih APK, buat keystore Anda sendiri dan simpan aman. Jangan pernah mengunggah `.jks` atau password signing ke GitHub/hosting. Untuk Google Play, pilih **AAB** dan perhatikan kebijakan akun developer dan distribusi yang berlaku.

## Pengujian wajib pada dua toko nyata

1. Install satu APK INPOS di Android dan buka. Login toko `inpos` menggunakan akun yang valid; bila PIN awal masih aktif, ubah PIN.
2. Logout lalu login toko kedua dengan subdomain yang berbeda. Pastikan dashboard, produk, stok, transaksi, dan laporan **tidak memuat data toko pertama**.
3. Uji mode portrait/landscape, keyboard numerik, tombol Back, refresh dan koneksi putus, unggah foto dan kamera bila UI barcode sudah diimplementasikan.
4. Uji keluar aplikasi lalu buka lagi: cookie sesi masih sesuai masa berlaku; logout harus menghapus sesi.
5. Uji kamera dan berbagi/cetak struk secara terpisah bila fitur tersebut sudah tersedia di aplikasi web. **Integrasi printer Bluetooth ESC/POS 58/80 mm belum dibuat dalam paket ini**.
6. Coba buka link eksternal; harus beralih ke browser/aplikasi lain, bukan menggantikan halaman kasir dalam APK.

## Batasan penting

- Proyek ini **memuat website**, jadi internet dan server cPanel/API diperlukan saat beroperasi; tidak menjamin transaksi offline atau sinkronisasi offline.
- Fitur native spesifik seperti Bluetooth thermal printing dan integrasi share PNG via sistem Android masih perlu modul tambahan.
- Akses super admin tetap di `adms.inpos.id` melalui browser/portal admin, tidak digabung ke APK kasir, sehingga pembatasan role tetap jelas.
- Desain APK mengikuti frontend versi **yang sedang terpasang di app.inpos.id**, bukan menyalin HTML lama ke APK. Untuk memastikan tampilan sama dengan ZIP revisi, upload frontend terbaru terlebih dahulu.
- Menggunakan Android WebView/Java tanpa dependency AndroidX tambahan; ini pilihan implementasi demi kesesuaian cookie dan UI, bukan proyek Capacitor.
- **APK aktual belum dibuild** dalam lingkungan penyusunan proyek karena Android SDK dan Gradle belum tersedia dan internet untuk mengunduhnya dibatasi. Semua kode harus diuji di Android Studio sebelum distribusi.

## Alternatif build melalui GitHub Actions (tanpa Android Studio lokal)

Unggah **isi proyek** ke repository GitHub milik Anda (jangan menyertakan secret maupun keystore), lalu masuk **Actions > INPOS Android APK (Debug) > Run workflow**. Setelah job berhasil, unduh artifact `INPOS-Android-Debug-APK` yang berisi `app-debug.apk`. Job tersebut menggunakan Android SDK 36 dan JDK 17 serta mengunduh Gradle secara resmi. Ini belum bisa menggantikan pengujian langsung di perangkat Android; jangan dianggap build release produksi.

**Penting:** APK debug bukan aplikasi Play Store, dan Anda harus menghormati status akun developer serta aturan distribusi Google Play. Jika ingin menggunakan nama package dan penandatanganan tetap, jangan membagikan debug APK sebagai rilis final.
