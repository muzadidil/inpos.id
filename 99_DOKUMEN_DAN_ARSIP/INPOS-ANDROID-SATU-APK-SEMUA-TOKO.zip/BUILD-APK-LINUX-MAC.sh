#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
./gradlew --no-daemon assembleDebug
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'
