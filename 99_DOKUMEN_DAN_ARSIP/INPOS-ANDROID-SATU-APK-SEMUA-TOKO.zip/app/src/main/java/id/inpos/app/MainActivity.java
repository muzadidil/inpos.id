package id.inpos.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.http.SslError;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * INPOS Android: one APK for all tenants.
 * Only https://app.inpos.id may run inside this WebView.
 * Login sessions are HttpOnly cookies on api.inpos.id; no PIN or JWT is stored by native code.
 */
public final class MainActivity extends Activity {
    private static final String APP_URL = "https://app.inpos.id/";
    private static final String TRUSTED_HOST = "app.inpos.id";
    private static final int CAMERA_REQUEST = 1301;
    private static final int FILE_REQUEST = 1302;
    private WebView webView;
    private LinearLayout overlay;
    private TextView overlayMessage;
    private Button retryButton;
    private ProgressBar spinner;
    private boolean mainFrameError = false;
    private PermissionRequest pendingCameraRequest;
    private ValueCallback<Uri[]> pendingFileChooser;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        makeOverlay(root);
        setContentView(root);
        // Android 15/16 edge-to-edge: avoid overlapping the status bar and bottom navigation.
        if (Build.VERSION.SDK_INT >= 35) {
            getWindow().getDecorView().setOnApplyWindowInsetsListener((decor, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                root.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
                return insets;
            });
        }
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // Required by trusted INPOS UI.
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // User-initiated HTML file input.
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(true); // Block pop-ups/new WebViews.
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSafeBrowsingEnabled(true);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        webView.setWebViewClient(new SiteClient());
        webView.setWebChromeClient(new SiteChromeClient());
        // Do not attach an unrestricted JavaScriptInterface to remote pages.
        if (state == null) webView.loadUrl(APP_URL);
        else if (webView.restoreState(state) == null) webView.loadUrl(APP_URL);
    }

    private void makeOverlay(FrameLayout root) {
        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setGravity(Gravity.CENTER);
        overlay.setPadding(dp(28), dp(28), dp(28), dp(28));
        overlay.setBackgroundColor(Color.WHITE);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.inpos_icon);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(104), dp(104));
        lp.bottomMargin = dp(12);
        overlay.addView(logo, lp);
        spinner = new ProgressBar(this);
        overlay.addView(spinner, new LinearLayout.LayoutParams(dp(36), dp(36)));
        overlayMessage = new TextView(this);
        overlayMessage.setText(R.string.loading);
        overlayMessage.setTextSize(13);
        overlayMessage.setTextColor(Color.DKGRAY);
        overlayMessage.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-1, -2);
        mlp.topMargin = dp(18);
        overlay.addView(overlayMessage, mlp);
        retryButton = new Button(this);
        retryButton.setText(R.string.retry);
        retryButton.setTextColor(Color.WHITE);
        retryButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(225,29,46)));
        retryButton.setOnClickListener(v -> { showLoading(); webView.loadUrl(APP_URL); });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-2, -2);
        blp.topMargin = dp(14);
        overlay.addView(retryButton, blp);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        retryButton.setVisibility(View.GONE);
    }

    private int dp(int px) { return Math.round(px * getResources().getDisplayMetrics().density); }
    private void showLoading() {
        mainFrameError = false;
        overlay.setVisibility(View.VISIBLE);
        overlayMessage.setText(R.string.loading);
        spinner.setVisibility(View.VISIBLE);
        retryButton.setVisibility(View.GONE);
    }
    private void showError() {
        mainFrameError = true;
        overlay.setVisibility(View.VISIBLE);
        overlayMessage.setText(R.string.offline);
        spinner.setVisibility(View.GONE);
        retryButton.setVisibility(View.VISIBLE);
    }

    private static boolean trusted(Uri uri) {
        return uri != null && "https".equalsIgnoreCase(uri.getScheme())
               && TRUSTED_HOST.equalsIgnoreCase(uri.getHost())
               && uri.getPort() == -1;
    }
    private void openOutside(Uri uri) {
        if (uri == null) return;
        String scheme = uri.getScheme();
        if (scheme == null) return;
        scheme = scheme.toLowerCase(java.util.Locale.ROOT);
        if (!(scheme.equals("https") || scheme.equals("mailto") || scheme.equals("tel"))) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)); }
        catch (ActivityNotFoundException ignored) {
            new AlertDialog.Builder(this).setMessage("Tidak ada aplikasi untuk membuka tautan.")
                .setPositiveButton("OK", null).show();
        }
    }

    private class SiteClient extends WebViewClient {
        @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (trusted(uri)) return false;
            if (request.isForMainFrame() && request.hasGesture()) openOutside(uri);
            return true;
        }
        @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
            Uri uri = Uri.parse(url);
            if (trusted(uri)) return false;
            openOutside(uri);
            return true;
        }
        @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
            if (trusted(Uri.parse(url))) showLoading();
            else { view.stopLoading(); showError(); }
        }
        @Override public void onPageFinished(WebView view, String url) {
            if (!mainFrameError && trusted(Uri.parse(url))) overlay.setVisibility(View.GONE);
        }
        @Override public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError error) {
            if (req.isForMainFrame()) showError();
        }
        @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.cancel(); // Never bypass TLS failures.
            showError();
        }
    }

    private class SiteChromeClient extends WebChromeClient {
        @Override public void onPermissionRequest(PermissionRequest request) {
            runOnUiThread(() -> {
                if (!trusted(request.getOrigin())) { request.deny(); return; }
                String[] resources = request.getResources();
                if (resources.length != 1 || !PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resources[0])) {
                    request.deny(); return;
                }
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                } else {
                    if (pendingCameraRequest != null) pendingCameraRequest.deny();
                    pendingCameraRequest = request;
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
                }
            });
        }
        @Override public void onPermissionRequestCanceled(PermissionRequest request) {
            if (pendingCameraRequest == request) pendingCameraRequest = null;
        }
        @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                                   FileChooserParams params) {
            if (pendingFileChooser != null) pendingFileChooser.onReceiveValue(null);
            pendingFileChooser = callback;
            try { startActivityForResult(params.createIntent(), FILE_REQUEST); return true; }
            catch (ActivityNotFoundException ex) {
                pendingFileChooser = null;
                callback.onReceiveValue(null);
                return false;
            }
        }
    }

    @Override public void onRequestPermissionsResult(int reqCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(reqCode, permissions, results);
        if (reqCode != CAMERA_REQUEST || pendingCameraRequest == null) return;
        PermissionRequest r = pendingCameraRequest;
        pendingCameraRequest = null;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED)
            r.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        else r.deny();
    }
    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == FILE_REQUEST && pendingFileChooser != null) {
            ValueCallback<Uri[]> callback = pendingFileChooser;
            pendingFileChooser = null;
            callback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
        }
    }

    @Override public void onBackPressed() {
        // Native Back closes the mobile 'More' drawer or returns to Dashboard.
        // This controlled script runs only after a trusted origin has loaded.
        if (trusted(Uri.parse(webView.getUrl()))) {
            webView.evaluateJavascript("(function(){try{var m=document.getElementById('mobileMore');"
                + "if(m&&!m.classList.contains('hidden')){m.classList.add('hidden');return 'handled';}"
                + "if(typeof tab!=='undefined'&&typeof switchTab==='function'&&tab!=='dashboard'&&(typeof transactionBusy==='undefined'||!transactionBusy)){switchTab('dashboard');return 'handled';}"
                + "return 'pass';}catch(e){return 'pass';}})()", result -> {
                    if ("\"handled\"".equals(result)) return;
                    if (webView.canGoBack()) webView.goBack();
                    else confirmExit();
                });
        } else if (webView.canGoBack()) webView.goBack();
        else confirmExit();
    }
    private void confirmExit() {
        new AlertDialog.Builder(this).setTitle("Keluar dari INPOS?")
            .setMessage("Anda dapat membuka INPOS kembali tanpa kehilangan sesi login.")
            .setNegativeButton("Batal", null).setPositiveButton("Keluar", (d,w) -> finish()).show();
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        webView.saveState(out);
        super.onSaveInstanceState(out);
    }
    @Override protected void onPause() {
        super.onPause();
        webView.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        webView.onResume();
    }
    @Override protected void onDestroy() {
        if (pendingCameraRequest != null) { pendingCameraRequest.deny(); pendingCameraRequest = null; }
        if (pendingFileChooser != null) { pendingFileChooser.onReceiveValue(null); pendingFileChooser = null; }
        if (webView != null) {
            webView.stopLoading();
            ((ViewGroup)webView.getParent()).removeView(webView);
            webView.destroy(); webView = null;
        }
        super.onDestroy();
    }
}
