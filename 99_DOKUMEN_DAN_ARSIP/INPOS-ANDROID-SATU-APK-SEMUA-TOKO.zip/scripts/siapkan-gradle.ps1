$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
$file='gradle/wrapper/gradle-wrapper.jar'
$expected='81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f'
if (!(Test-Path $file)) {
  Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.13-wrapper.jar' -OutFile $file
}
$actual=(Get-FileHash $file -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $expected) { throw 'Checksum Gradle wrapper tidak cocok!' }
Write-Host 'Gradle wrapper sudah siap.'
