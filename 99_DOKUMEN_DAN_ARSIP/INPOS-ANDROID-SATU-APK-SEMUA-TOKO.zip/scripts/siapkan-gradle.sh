#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
FILE=gradle/wrapper/gradle-wrapper.jar
URL=https://services.gradle.org/distributions/gradle-8.13-wrapper.jar
SHA=81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f
if [ ! -f "$FILE" ]; then
  echo "Mengunduh Gradle wrapper resmi..."
  curl -fLSs --retry 3 "$URL" -o "$FILE"
fi
echo "$SHA  $FILE" | sha256sum -c -
