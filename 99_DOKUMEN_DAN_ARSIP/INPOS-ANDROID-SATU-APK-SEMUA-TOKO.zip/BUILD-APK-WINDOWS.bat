@echo off
cd /d "%~dp0"
call gradlew.bat --no-daemon assembleDebug
if errorlevel 1 (
 echo Build gagal. Baca README dan periksa Android SDK 36/JDK 17/koneksi internet.
 exit /b 1
)
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
